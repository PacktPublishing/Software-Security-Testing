<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");

if(isset($_GET["title"]) and $_GET["title"])
{

    // Creates the movie table
    $movies = array("CAPTAIN AMERICA", "IRON MAN", "SPIDER-MAN", "THE INCREDIBLE HULK", "THE WOLVERINE", "THOR", "X-MEN");

    if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2")
    {

        // Retrieves the movie title
        $title = $_GET["title"];

    }

    else
    {

        $title = xss_check_3($_GET["title"]);

    }

    // Generates the output depending on the movie title received from the client
    if(in_array(strtoupper($title), $movies))
        $string = '{"movies":[{"response":"Yes! We have that movie..."}]}';
    else
        $string = '{"movies":[{"response":"' . $title . '??? Sorry, we don&#039;t have that movie :("}]}';

}

else
{

	$string = '{"movies":[{"response":"HINT: our master really loves Marvel movies :)"}]}';
}

?>

<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Reflected (JSON)</h1>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="GET">



                <label for="title">Search for a movie:</label>
                <input class="form-control" type="text" id="title" name="title">
            <br>
                <button class="btn btn-info" type="submit" name="action" value="search">Search</button>



        </form>

        <div id="result"></div>

        <script>

            var JSONResponseString = '<?php echo $string ?>';

            // var JSONResponse = eval ("(" + JSONResponseString + ")");
            var JSONResponse = JSON.parse(JSONResponseString);

            document.getElementById("result").innerHTML=JSONResponse.movies[0].response;

        </script>

    </div>
</div>
<?php include "./layouts/footer.php";?>

