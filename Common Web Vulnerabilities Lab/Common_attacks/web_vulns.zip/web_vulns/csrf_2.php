<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

if(isset($_GET["amount"]))
{

    if(($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2"))    
    {

        $_SESSION["amount"] = $_SESSION["amount"] - $_GET["amount"];    

    }

    else

        if(isset($_GET["action"]) && isset($_GET["token"]) && isset($_SESSION["token"]))
        {    

            if(($_GET["token"] == $_SESSION["token"]) && ($_GET["action"]) == "transfer")
            {

                $_SESSION["amount"] = $_SESSION["amount"] - $_GET["amount"];

            }

        }

}

// A random token is generated when the security level is HIGH
if($_COOKIE["security_level"] == "2")
{

    $token = sha1(uniqid(mt_rand(0,100000)));
    $_SESSION["token"] = $token;

}

?>



<?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">

            <h1>CSRF (Transfer Amount)</h1>

            <p>Amount on your account: <b> <?php echo $_SESSION["amount"] ?> EUR</b></p>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="GET">

                <label for="account">Account to transfer:</label>
                    <input type="text" class="form-control" id="account" name="account" value="123-45678-90">

                <label for="amount">Amount to transfer:</label>
                    <input class="form-control" type="text" id="amount" name="amount" value="0">

                <?php

                if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
                {

                    ?>
                    <input type="hidden" id="token" name="token" value="<?php echo $_SESSION["token"]?>">

                    <?php

                }

                ?>
                <br>
                <button class="btn btn-info" type="submit" name="action" value="transfer">Transfer</button>

            </form>
        </div>
    </div>
<?php include "./layouts/footer.php";?>