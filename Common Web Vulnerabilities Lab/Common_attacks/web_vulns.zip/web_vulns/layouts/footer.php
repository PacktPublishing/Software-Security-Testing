<!-- Default box -->
</div>
</div>
</div>
</section>
<!-- /.content -->
</div>




<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"
        integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
        integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm"
        crossorigin="anonymous"></script>




<script>
    $(document).ready(function(){
        $("#p_a1").click(function(){
            $("#a1").toggle();
        });
        $("#p_a2").click(function(){
            $("#a2").toggle();
        });
        $("#p_a3").click(function(){
            $("#a3").toggle();
        });
        $("#p_a4").click(function(){
            $("#a4").toggle();
        });
        $("#p_a5").click(function(){
            $("#a5").toggle();
        });
        $("#p_a6").click(function(){
            $("#a6").toggle();
        });
        $("#p_a7").click(function(){
            $("#a7").toggle();
        });
        $("#p_a8").click(function(){
            $("#a8").toggle();
        });
        $("#p_a9").click(function () {
            $("#a9").toggle();
        });
        $("#p_a10").click(function () {
            $("#a10").toggle();
        });
        $("#p_other").click(function () {
            $("#other").toggle();
        });



    });
</script>

</body>
</html>

