<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>InfoSec</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script src="js/html5.js"></script>
    <script src="js/jquery-1.4.4.min.js"></script>
    <script src="js/json2.js"></script>
    <script src="js/xss_ajax_1.js"></script>
    <link rel="stylesheet" href="/dist/css/adminlte.min.css">
    <!--Kit link-->
    <script src="https://kit.fontawesome.com/7135c7649e.js" crossorigin="anonymous"></script>

    <style>
        #item:hover {
            background-color: rgb(101, 102, 101);
            color: white;
        }
    </style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="portal.php">Bugs</a>

            </li>
            <li class="nav-item">
                <a class="nav-link" href="password_change.php">Change Password</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="user_extra.php">Create User</a>
            </li>
            <li>
                <a class="nav-link" href="security_level_set.php">Set Security Level</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="reset.php"
                   onclick="return confirm('All settings will be cleared. Are you sure?');">Reset</a>
            </li>


        </ul>
        <ul class="navbar-nav">

            <li class="nav-item mr-5">
                <a class="nav-link" href="#">Welcome <b><?php if (isset($_SESSION["login"])) {
                            echo ucwords($_SESSION["login"]);
                        } ?></b> </a>
            </li>
            <li class="nav-item mr-2">
                <a class="nav-link" href="logout.php" onclick="return confirm('Are you sure you want to leave?');">Logout</a>
            </li>
        </ul>
    </div>

</nav>
<!-- Site wrapper -->
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-light navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">

            <li class="nav-item d-none d-sm-inline-block">
                <a href="/" class="nav-link">Cyber Academy</a>
            </li>

        </ul>
        <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <!-- <ul class="navbar-nav">
             </ul>-->
        </div>
    </nav>


    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4" id="pushmenu1">
        <!-- Brand Logo -->


        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user (optional) -->


            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->



                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a1">
                                <i class="fas fa-robot"></i>
                                A1 - Injections
                            </p>
                            <ul id="a1" class="collapse">

                                <li><a class="nav-link" id="item"
                                       href="htmli_get.php">HTML Injection - Reflected (GET)
                                        2</a></li>
                                <li><a class="nav-link" id="item" href="htmli_post.php">HTML Injection - Reflected
                                        (POST)</a></li>
                                <li><a class="nav-link" id="item" href="htmli_current_url.php">HTML Injection -
                                        Reflected (Current URL)</a></li>
                                <li><a class="nav-link" id="item" href="htmli_stored.php">HTML Injection - Stored
                                        (Blog)</a></li>
                                <li><a class="nav-link" id="item" href="iframei.php">iFrame Injection</a></li>
                                <li><a class="nav-link" id="item" href="maili.php">Mail Header Injection (SMTP)</a></li>
                                <li><a class="nav-link" id="item" href="commandi.php">OS Command Injection</a></li>
                                <li><a class="nav-link" id="item" href="commandi_blind.php">OS Command Injection -
                                        Blind</a></li>
                                <li><a class="nav-link" id="item" href="phpi.php">PHP Code Injection</a></li>
                                <li><a class="nav-link" id="item" href="ssii.php">Server-Side Includes (SSI)
                                        Injection</a></li>
                                <li><a class="nav-link" id="item" href="sqli_1.php">SQL Injection (GET/Search)</a></li>
                                <li><a class="nav-link" id="item" href="sqli_2.php">SQL Injection (GET/Select)</a></li>
                                <li><a class="nav-link" id="item" href="sqli_6.php">SQL Injection (POST/Search)</a></li>
                                <li><a class="nav-link" id="item" href="sqli_13.php">SQL Injection (POST/Select)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="sqli_10-1.php">SQL Injection
                                        (AJAX/JSON/jQuery)</a></li>
                                <li><a class="nav-link" id="item" href="sqli_3.php">SQL Injection (Login Form/Hero)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="sqli_16.php">SQL Injection (Login Form/User)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="sqli_7.php">SQL Injection - Stored (Blog)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="sqli_12.php">SQL Injection - Stored (SQLite)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="sqli_17.php">SQL Injection - Stored
                                        (User-Agent)</a></li>
                                <li><a class="nav-link" id="item" href="sqli_4.php">SQL Injection - Blind -
                                        Boolean-Based</a></li>
                                <li><a class="nav-link" id="item" href="sqli_15.php">SQL Injection - Blind -
                                        Time-Based</a></li>
                                <li><a class="nav-link" id="item" href="sqli_14.php">SQL Injection - Blind (SQLite)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="xmli_1.php">XML/XPath Injection (Login Form)</a>
                                </li>
                                <li><a class="nav-link" id="item" href="xmli_2.php">XML/XPath Injection (Search)</a>
                                </li>
                            </ul>

                        </div>
                    </li>


                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a2">
                                <i class="fas fa-robot"></i>
                                A2 - Broken Auth. & Session Mgmt
                            </p>
                            <ul id="a2" class="collapse">

                                <li><a class="nav-link" id="item" href="ba_forgotten.php">Broken Authentication -
                                        Forgotten Function</a></li>
                                <li><a class="nav-link" id="item" href="ba_logout.php">Broken Authentication - Logout
                                        Management</a></li>
                                <li><a class="nav-link" id="item" href="ba_pwd_attacks.php">Broken Authentication -
                                        Password Attacks</a></li>
                                <li><a class="nav-link" id="item" href="ba_weak_pwd.php">Broken Authentication - Weak
                                        Passwords</a></li>
                                <li><a class="nav-link" id="item" href="smgmt_admin_portal.php">Session Management -
                                        Administrative Portals</a></li>
                                <li><a class="nav-link" id="item" href="smgmt_cookies_httponly.php">Session Management -
                                        Cookies (HTTPOnly)</a></li>
                                <li><a class="nav-link" id="item" href="smgmt_cookies_secure.php">Session Management -
                                        Cookies (Secure)</a></li>
                                <li><a class="nav-link" id="item" href="smgmt_sessionid_url.php">Session Management -
                                        Session ID in URL</a></li>
                                <li><a class="nav-link" id="item" href="smgmt_sessionid_url.php">Session Management -
                                        Strong Sessions</a></li>


                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a3">
                                <i class="fas fa-robot"></i>
                                A3 - Cross-Site Scripting (XSS)
                            </p>
                            <ul id="a3" class="collapse">

                                <li><a class="nav-link" id="item" href="xss_get.php">Cross-Site Scripting -
                                        Reflected </a></li>
                                <li><a class="nav-link" id="item" href="xss_post.php">Cross-Site Scripting - Reflected
                                        (POST)</a></li>
                                <li><a class="nav-link" id="item" href="xss_json.php">Cross-Site Scripting - Reflected
                                        (JSON)</a></li>
                                <li><a class="nav-link" id="item" href="xss_ajax_2-1.php">Cross-Site Scripting -
                                        Reflected (AJAX/JSON)</a></li>
                                <li><a class="nav-link" id="item" href="xss_ajax_1-1.php">Cross-Site Scripting -
                                        Reflected (AJAX/XML)</a></li>
                                <li><a class="nav-link" id="item" href="xss_back_button.php">Cross-Site Scripting -
                                        Reflected (Back Button)</a></li>
                                <li><a class="nav-link" id="item" href="xss_eval.php?date=Date()">Cross-Site Scripting -
                                        Reflected (Eval)</a></li>
                                <li><a class="nav-link" id="item" href="xss_href-1.php">Cross-Site Scripting - Reflected
                                        (HREF)</a></li>
                                <li><a class="nav-link" id="item" href="xss_login.php">Cross-Site Scripting - Reflected
                                        (Login Form)</a></li>
                                <li><a class="nav-link" id="item" href="xss_referer.php">Cross-Site Scripting -
                                        Reflected (Referer)</a></li>
                                <li><a class="nav-link" id="item" href="xss_user_agent.php">Cross-Site Scripting -
                                        Reflected (User-Agent)</a></li>
				<li><a class="nav-link" id="item" href="xss_dom.php">Cross-Site Scripting - DOM</a></li>
                                <li><a class="nav-link" id="item" href="xss_stored_1.php">Cross-Site Scripting - Stored
                                        (Blog)</a></li>
                                <li><a class="nav-link" id="item" href="xss_stored_3.php">Cross-Site Scripting - Stored
                                        (Change Secret)</a></li>
                                <li><a class="nav-link" id="item" href="xss_stored_2.php">Cross-Site Scripting - Stored
                                        (Cookies)</a></li>
                                <li><a class="nav-link" id="item" href="xss_stored_4.php">Cross-Site Scripting - Stored
                                        (User-Agent)</a></li>


                            </ul>

                        </div>
                    </li>


                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a4">
                                <i class="fas fa-robot"></i>
                                A4 - Insecure Direct Object References
                            </p>
                            <ul id="a4" class="collapse">

                                <li><a class="nav-link" id="item" href="insecure_direct_object_ref_1.php">Insecure DOR
                                        (Change Secret) </a>
                                </li>
                                <li><a class="nav-link" id="item" href="insecure_direct_object_ref_3.php">Insecure DOR
                                        (Reset Secret)</a></li>
                                <li><a class="nav-link" id="item" href="insecure_direct_object_ref_2.php">Insecure DOR
                                        (Order Tickets)</a></li>
                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a5">
                                <i class="fas fa-robot"></i>
                                A5 - Security Misconfiguration
                            </p>
                            <ul id="a5" class="collapse">

                                <li><a class="nav-link" id="item" href="sm_cors.php">Cross-Origin Resource Sharing (AJAX) </a></li>
                                <li><a class="nav-link" id="item" href="sm_mitm_2.php">Man-in-the-Middle Attack (SMTP) </a></li>
                                <li><a class="nav-link" id="item" href="sm_obu_files.php">Old/Backup & Unreferenced Files</a></li>
                                <li><a class="nav-link" id="item" href="sm_robots.php">Robots File</a></li>

                            </ul>

                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a6">
                                <i class="fas fa-robot"></i>
                                A6 - Sensitive Data Exposure
                            </p>
                            <ul id="a6" class="collapse">

                                <li><a class="nav-link" id="item" href="insecure_crypt_storage_3.php">Base64 Encoding (Secret)</a></li>
                                <li><a class="nav-link" id="item" href="insuff_transp_layer_protect_1.php">Clear Text HTTP (Credentials)</a></li>
                                <li><a class="nav-link" id="item" href="hostheader_2.php">Host Header Attack (Reset Poisoning)</a></li>
                                <li><a class="nav-link" id="item" href="insecure_crypt_storage_1.php">HTML5 Web Storage (Secret)</a></li>
                                <li><a class="nav-link" id="item" href="insecure_crypt_storage_2.php">Text Files (Accounts)</a></li>


                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a7">
                                <i class="fas fa-robot"></i>
                                A7 - Missing Functional Level Access Control
                            </p>
                            <ul id="a7" class="collapse">
				<li><a class="nav-link" id="item" href="directory_traversal_1.php?page=message.txt">Directory Traversal - Files</a></li>
                                <li><a class="nav-link" id="item" href="directory_traversal_2.php?directory=documents">Directory Traversal - Directories</a></li>
                                <li><a class="nav-link" id="item" href="hostheader_1.phpp">Host Header Attack (Cache Poisoning)</a></li>
                                <li><a class="nav-link" id="item" href="hostheader_2.php">Host Header Attack (Reset Poisoning)</a></li>
                                <li><a class="nav-link" id="item" href="rlfi.php">Remote & Local File Inclusion (RFI/LFI)</a></li>
                                <li><a class="nav-link" id="item" href="restrict_device_access.php">Restrict Device Access</a></li>
                                <li><a class="nav-link" id="item" href="restrict_folder_access.php">Restrict Folder Access</a></li>
                                <li><a class="nav-link" id="item" href="xxe-1.php">XML External Entity Attacks (XXE)</a></li>


                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a8">
                                <i class="fas fa-robot"></i>
                                A8 - Cross-Site Request Forgery (CSRF)
                            </p>
                            <ul id="a8" class="collapse">

                                <li><a class="nav-link" id="item" href="csrf_1.php">Cross-Site Request Forgery (Change Password)</a></li>
                                <li><a class="nav-link" id="item" href="csrf_3.php">Cross-Site Request Forgery (Change Secret)</a></li>
                                <li><a class="nav-link" id="item" href="csrf_2.php">Cross-Site Request Forgery (Transfer Amount)</a></li>


                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a9">
                                <i class="fas fa-robot"></i>
                                A9 - Using Known Vulnerable Components
                            </p>
                            <ul id="a9" class="collapse">

                                <li><a class="nav-link" id="item" href="bof_1.php">Buffer Overflow (Local)</a></li>
                                <li><a class="nav-link" id="item" href="php_eval.php">PHP Eval Function</a></li>



                            </ul>

                        </div>
                    </li>


                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_a10">
                                <i class="fas fa-robot"></i>
                                A10 - Unvalidated Redirects & Forwards
                            </p>
                            <ul id="a10" class="collapse">

                                <li><a class="nav-link" id="item" href="unvalidated_redir_fwd_1.php">Unvalidated Redirects & Forwards (1)</a></li>
                                <li><a class="nav-link" id="item" href="unvalidated_redir_fwd_2.php">Unvalidated Redirects & Forwards (2)</a></li>
                            </ul>

                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="nav-link">

                            <p id="p_other">
                                <i class="fas fa-robot"></i>
                                Other bugs...
                            </p>
                            <ul id="other" class="collapse">

                                <li><a class="nav-link" id="item" href="clickjacking.php">ClickJacking (Movie Tickets)</a></li>
                                <li><a class="nav-link" id="item" href="cs_validation.php">Client-Side Validation (Password)</a></li>
                                <li><a class="nav-link" id="item" href="hpp-1.php">HTTP Parameter Pollution</a></li>
                                <li><a class="nav-link" id="item" href="http_verb_tampering.php">HTTP Verb Tampering</a></li>
                                <li><a class="nav-link" id="item" href="information_disclosure_4.php">Information Disclosure - Favicon</a></li>
                                <li><a class="nav-link" id="item" href="information_disclosure_2.php">Information Disclosure - Headers</a></li>
                                <li><a class="nav-link" id="item" href="information_disclosure_3.php">Information Disclosure - Robots File</a></li>
                            </ul>

                        </div>
                    </li>


                </ul>


            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
