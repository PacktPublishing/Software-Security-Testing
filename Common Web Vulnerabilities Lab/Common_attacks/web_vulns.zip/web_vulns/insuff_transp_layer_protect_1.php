<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

$message = "";

switch($_COOKIE["security_level"])
{

    case "0" :

        $url = $_SERVER["SCRIPT_NAME"];
        break;

    case "1" :

        $message = "A certificate must be configured to fully function!";
        $url = "https://" . $_SERVER["HTTP_HOST"] . $_SERVER["SCRIPT_NAME"];
        break;

    case "2" :

        $message = "A certificate must be configured to fully function!";
        $url = "https://" . $_SERVER["HTTP_HOST"] . $_SERVER["SCRIPT_NAME"];
        break;

    default :

        $url = $_SERVER["SCRIPT_NAME"];
        break;

}

if(isset($_POST["form"]))   
{

    if($_POST["login"] == $login && $_POST["password"] == $password)
    {

        $message = "<font color=\"green\">Successful login!</font>";

    }

    else
    {

        $message = "<font color=\"red\">Invalid credentials!</font>";

    }

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Clear Text HTTP (Credentials)</h1>

        <p>Enter your credentials</p>

        <form action="<?php echo $url?>" method="POST">

            <label for="login">Login:</label>
                <input class="form-control" type="text" id="login" name="login" size="20" />

            <label for="password">Password:</label>
                <input class="form-control" type="password" id="password" name="password" size="20" />
            <br>
            <button class="btn btn-info" type="submit" name="form" value="submit">Login</button>

        </form>

        </br >
        <?php echo $message;?>
    </div>
</div>
<?php include "./layouts/footer.php";?>


