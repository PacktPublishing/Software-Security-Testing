<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$message = "";

if(isset($_REQUEST["genre"])) 
{
    
$genre = $_REQUEST["genre"];

    switch($_COOKIE["security_level"])
    {
        
        case "0" : 
            
            setcookie("movie_genre", $genre, time()+3600, "/", "", false, false);
                
            break;
        
        case "1" :
            
            $genre = xss_check_3($genre);

            setcookie("movie_genre", $genre, time()+3600, "/", "", false, false);

            break;;
        
        case "2" :
            
                switch($genre)
                {

                    case "action" :

                        $genre = "action";
                        break;

                    case "horror" :

                        $genre = "horror";
                        break;

                    case "sci-fi" :

                        $genre = "sci-fi";
                        break;

                    default : 

                        $genre = "unknown";
                        break;

                }
            
            setcookie("movie_genre", $genre, time()+3600, "/", "", false, false);
                
            break;
        
        default : 
            
            setcookie("movie_genre", $genre, time()+3600, "/", "", false, false);
                
            break;   

    }
    
    $message = "Thank you for making your choice!";

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Stored (Cookies)</h1>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="GET">

            <p>

                <label for="genre">Please choose your favorite movie genre: </label>
                <select class="form-control" name="genre">

                    <option value="action">Action</option>";
                    <option value="horror">Horror</option>";
                    <option value="sci-fi">Science Fiction</option>";

                </select>
                <br>
                <button type="submit" class="btn btn-info" name="form" value="like">Like</button>

            </p>

        </form>

        <?php echo $message;?>
    </div>
</div>
<?php include "./layouts/footer.php";?>

