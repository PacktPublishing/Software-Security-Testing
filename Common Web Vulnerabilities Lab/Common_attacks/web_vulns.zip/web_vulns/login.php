<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("connect_i.php");
include("admin/settings.php");

session_start();

$message = "";

if(isset($_POST["form"]))
{

    $login = $_POST["login"];
    $login = mysqli_real_escape_string($link, $login);

    $password = $_POST["password"];
    $password = mysqli_real_escape_string($link, $password);
    $password = hash("sha1", $password, false);

    $sql = "SELECT * FROM users WHERE login = '" . $login;
    $sql.= "' AND BINARY password = '" . $password . "'";
    // Checks if the user is activated
    $sql.= " AND activated = 1";

    // Debugging
    // echo $sql;

    $recordset = $link->query($sql);

    if(!$recordset)
    {

        die("Error: " . $link->error);

    }

    else
    {

        $row = $recordset->fetch_object();

        // Debugging
        // print_r($row);

        if($row)
        {

            session_regenerate_id(true);

            $token = sha1(uniqid(mt_rand(0,100000)));

            $_SESSION["login"] = $row->login;
            $_SESSION["admin"] = $row->admin;
            $_SESSION["token"] = $token;
            $_SESSION["amount"] = 1000;

            $security_level_cookie = $_POST["security_level"];

            switch($security_level_cookie)
            {

                case "0" :

                    $security_level_cookie = "0";
                    break;

                case "1" :

                    $security_level_cookie = "1";
                    break;

                case "2" :

                    $security_level_cookie = "2";
                    break;

                default :

                    $security_level_cookie = "0";
                    break;

            }

            if($evil_bee == 1)
            {

                setcookie("security_level", "666", time()+60*60*24*365, "/", "", false, false);

            }

            else
            {

                setcookie("security_level", $security_level_cookie, time()+60*60*24*365, "/", "", false, false);

            }

            header("Location: portal.php");

            exit;

        }

        else
        {

        $message = "<font color=\"red\">Invalid credentials or user not activated!</font>";

        }

    }

}

?>
<!DOCTYPE html>
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!--<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Architects+Daughter">-->
<link rel="stylesheet" type="text/css" href="stylesheets/stylesheet.css" media="screen" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<!--<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
<script src="js/html5.js"></script>

<title>Login</title>
    <style>
        #li-register{
            color: black;
        }
    </style>
</head>

<body>


    <nav class="navbar navbar-expand-lg  d-flex justify-content-between" id='nav'>
        <div class="navbar-brand d-flex row">

        </div>


        <ul class="navbar-nav ml-auto mr-5">
            <!-- Authentication Links -->
            <li class="nav-item" >
                <a class="nav-link" href="/login.php" id="li-register">Login</a>
            </li>
            <li class="nav-item" >
                <a class="nav-link" href="/user_new.php" id="li-register">Register</a>
            </li>

        </ul>
    </nav>

    <main class="py-4">

        <div class="container">
            <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card my-5">
                        <div class="card-body">
                            <h5 class="card-title text-center">Login</h5>


                            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

                                <p><label for="login">Login:</label><br />
                                    <input class="form-control" type="text" id="login" name="login" size="20" autocomplete="off"></p>

                                <p><label for="password">Password:</label><br />
                                    <input class="form-control" type="password" id="password" name="password" size="20" autocomplete="off"></p>

                                <p><label for="security_level">Set the security level:</label><br />

                                    <select class="form-control" name="security_level">

                                        <option value="0">low</option>
                                        <option value="1">medium</option>
                                        <option value="2">high</option>

                                    </select>

                                </p>
                                <br>


                                <button  class="btn btn-primary btn-lg btn-block" type="submit" name="form" value="submit">Login</button>

                            </form>
                            <br />
                            <?php

                            echo $message;

                            $link->close();

                            ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>

</body>

</html>
