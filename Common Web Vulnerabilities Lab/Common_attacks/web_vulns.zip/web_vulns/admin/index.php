<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("settings.php");

if(isset($_COOKIE["security_level"]))
{

    switch($_COOKIE["security_level"])
    {

        case "0" :

            $security_level = "low";
            break;

        case "1" :

            $security_level = "medium";
            break;

        case "2" :

            $security_level = "high";
            break;

        case "666" :

            $security_level = "666";
            break;

        default :

            $security_level = "low";
            break;

    }

}

else
{

    $security_level = "not set";

}

?>
<!DOCTYPE html>
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!--<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Architects+Daughter">-->
<link rel="stylesheet" type="text/css" href="../stylesheets/stylesheet.css" media="screen" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<!--<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
<script src="../js/html5.js"></script>

<title>Admin Panel</title>

</head>

<body style="background: white">
<?php include "../layouts/header1.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Settings</h1>

        <table class="table">

            <tr>

                <td width="150"><b>Setting</b></td>
                <td width="150"><b>Value</b></td>
                <td width="540"><b>Description</b></td>

            </tr>

            <tr height="50">

                <td>Security Level</td>
                <td align="center"><?php echo $security_level ?></td>
                <td>Possible values: low - medium - high</td>

            </tr>

            <tr height="50">

                <td>SMTP Server</td>
                <td align="center"><?php echo $smtp_server ?></td>
                <td>Used for e-mail functionality</td>

            </tr>

            <tr height="50">

                <td>A.I.M. IP Address</td>
                <td align="center"><?php echo $AIM_IPs[0] ?></td>
                <td>A no-authentication mode, for testing web scanners and crawlers</td>

            </tr>

            <tr height="50">

                <td>Evil Bee Mode</td>
                <td align="center"><?php echo $evil_bee ?></td>
                <td>All security levels are bypassed in this mode</td>

            </tr>

            <tr height="50">

                <td>Credentials</td>
                <td align="center"><?php echo $login . "/" . $password ?></td>
                <td>Static credentials used on some pages</td>

            </tr>

        </table>



    </div>
</div>



</body>

</html>