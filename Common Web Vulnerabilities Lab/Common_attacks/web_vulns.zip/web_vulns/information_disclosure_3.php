<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$message = "";
$file = "robots.txt";
$catch = false;

switch($_COOKIE["security_level"])
{

    case "0" :            

        $color_1 = "";        
        $color_2 = "";
        
        break;

    case "1" :         

        $color_1 = "red";        
        $color_2 = "green";
        
        $message = "Don't place any sensitive files or directories in the <i>robots.txt</i> file!";
        
        break;

    case "2" :

        $color_1 = "red";        
        $color_2 = "green";
        
        $message = "Don't place any sensitive files or directories in the <i>robots.txt</i> file!";
        
        break;

    default :           

        $color_1 = "";        
        $color_2 = "";

}

?>



<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">

        <h1>Information Disclosure - Robots File</h1>

        Contents of <i>robots.txt</i>:

        <br /><br />

        <?php

        // Checks whether a file or directory exists
        if(is_file($file))
        {

            $banned = array("admin", "documents", "passwords");

            // Opens the file
            $fp = fopen($file, "r") or die("Couldn't open $file.");

            while(!feof($fp))
            {

                // Reads 1 line from the file
                $line = fgets($fp,1024);

                // Checks if a banned word is present in the current line
                foreach($banned as $str)
                {

                    if(strpos($line, $str) !== false)
                    {

                        $catch = true;

                    }

                }

                // If a banned word is present then the line is written with color 1
                if($catch == true)
                {

                    echo "<font color=\"" . $color_1 . "\">" . $line . "</font><br />";

                }

                // If a banned word is not present then the line is written with color 2
                else
                {

                    echo "<font color=\"" . $color_2 . "\">" . $line . "</font><br />";

                }

                $catch = false;

            }

        }

        ?>


        <?php echo "<br />" . $message;?>

    </div>
</div>
<?php include "./layouts/footer.php";?>
