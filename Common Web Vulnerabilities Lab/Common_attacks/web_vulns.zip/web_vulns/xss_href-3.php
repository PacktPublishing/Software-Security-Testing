<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("connect.php");
include("selections.php");

$message = "";

if(isset($_GET["name"]) && isset($_GET["movie"]) && isset($_GET["action"]) && $_GET["action"]="vote")
{
    
    // Detects multiple params with the same name (HTTP Parameter Pollution)            
    $hpp_error="";

    $hpp_error = hpp_check_1(urldecode($_SERVER["QUERY_STRING"]));

    if($hpp_error && $_COOKIE["security_level"] == 2)
    {

        $message = $hpp_error;

    }
        
    else
    {

        $movie = $_REQUEST["movie"];
        $mysqli = new mysqli("localhost", "root", "", "bwapp");
        $sql = "SELECT * FROM movies WHERE id = '" . $movie . "'";

        $recordset = mysqli_query($mysqli, $sql);

        if(!$recordset)
        {

            die("Error: " . mysqli_error());

        }

        if(mysqli_num_rows($recordset) != 0)
        {    

            while($row = mysqli_fetch_array($recordset))
            {

                // print_r($row);

                $message = "<p>Your favorite movie is: <b>" . $row["title"] . "</b></p>"; 
                $message.= "<p>Thank you for submitting your vote!</p>";                   

            }

        }

        else
        {

             $message = "<font color=\"red\">Something went wrong...</font>";       

        }
        
        mysqli_close($link);

    }

}

else
{

    header("Location: xss_href-1.php");

    exit;
}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Reflected (HREF)</h1>

        <?php echo $message ?>
    </div>
</div>


<?php include "./layouts/footer.php";?>