<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

if(isset($_POST["form"]) && isset($_POST["bug"]))
{

    $key = $_POST["bug"];
    $bug = explode(",", trim($bugs[$key]));

    // Debugging
    // echo " value: " . $bug[0];
    // echo " filename: " . $bug[1] . "<br />";

    header("Location: " . $bug[1]);

}

?>



<?php include ('./layouts/header.php')?>



<br>
<br>



        <section class="content-header">
            <div class="container-fluid">
                <div class="card-body text-center">
                    <img src="/image_project/logo1.png" width="600" height="300">
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <p>The <strong>Cyber Academy</strong> is an organization that specializes in training and
                                certifications for cybersecurity professionals. It described as the first cyber
                                education
                                organization in the SEE region, providing advanced curriculum and outstanding
                                examination/assessment for individuals and corporations. The most widely known
                                certification
                                offered by (CA) is the Cyber Academy Certified Professional <strong>(CACP)</strong>
                                certification.</p>
                            <p>Today our graduates are prolific contributors to the tech industry. Over the years, they
                                have
                                helped governments prosecute computer crime and routinely advised on topics like
                                electronic
                                surveillance, cyber warfare, APT threats, and more.

                                It is now domiciled in the United States with a team of Specialized Engineers, Former
                                Military /
                                <strong>Navy SEALS Personnel</strong>, and Former US Government Officials. The founding
                                of the
                                company is based in the Republic of Kosovo and Bosnia and Herzegovina. Cyber Academy
                                provides
                                cutting-edge cyber-education services in Banking / Credit / Financial, Government /
                                Military,
                                Healthcare / Medical, Manufacturing, Energy / Utilities, Critical Information
                                Infrastructure
                                Industries, Cyber Security, and Information Technology.

                                Extensive Staff Background in Security Services
                                International Team of Experts within <strong>NATO</strong> Space
                                Experience in Establishing National Cyber Security Strategies and CSIRTs
                                Various degrees of Security Clearance levels

                                The trainings are based under <strong>NIST</strong>, <strong>NICE</strong> Cybersecurity
                                Workforce Framework, <strong>DoD Directive 8570.1</strong> standards.</p>
                            <p><strong>Cyber Academy</strong> provides relevant and regularly updated content, full and
                                part-time online services, better engagement, experiences that <strong>boost</strong>
                                persistence, fast and straightforward assessments, quick content delivery, streamlined
                                programs,
                                and progress based on demonstrated <strong>mastery</strong>.


                            </p>

                        </div>
                    </div>


                </div>
            </div><!-- /.container-fluid -->
        </section>











<?php include './layouts/footer.php'?>