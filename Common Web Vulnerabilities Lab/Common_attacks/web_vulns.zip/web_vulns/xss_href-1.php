<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Reflected (HREF)</h1>

        <form action="xss_href-2.php" method="GET">

            <p>In order to vote for your favorite movie, your name must be entered:</p>

            <input  class="form-control" type="text" name="name">
            <br>
            <button class="btn btn-info" type="submit" name="action" value="vote">Continue</button>

        </form>
    </div>
</div>
<?php include "./layouts/footer.php";?>



