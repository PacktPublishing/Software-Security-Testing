<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

// Sets the directory
$directory = "documents";

// Downloads a file
if(isset($_GET["file"])) 
{

    $file = $_GET["file"];
    
    // Checks for directory traversal
    $directory_traversal_error = directory_traversal_check_3($file, $base_path = "./" . $directory); 
        
    if(!$directory_traversal_error)
    {

        // Checks if the file exists
        if(is_file($file)) 
        {

            // Debugging
            // echo $file;      
            
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=" . basename($file));
            header("Content-Transfer-Encoding: binary");
            header("Expires: 0");
            header("Cache-Control: must-revalidate");
            header("Pragma: public");
            header("Content-Length: " . filesize($file));

            ob_clean();

            flush();

            readfile($file) or die("Couldn't open $file.");

            exit;

        }
        
    }
        
}

?>





<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Restrict Folder Access</h1>

        <p>Only authorized users have access to the <i><?php echo $directory ?></i> folder.</p>

        <p>Log off and try to access files in this directory...</p>

        <?php

        switch($_COOKIE["security_level"])
        {

            case "0" :

                // Deletes the '.htaccesss' file
                if(file_exists($directory . "/.htaccess"))
                {

                    unlink($directory . "/.htaccess");

                }

                $dp = opendir($directory);

                while($line = readdir($dp))
                {

                    if($line != "." && $line != "..")
                    {

                        echo "<a href=\"" . $directory . "/" . $line . "\" target=\"_blank\">" . $line . "</a><br />";

                    }

                }

                break;

            case "1" :

                // Creates the '.htaccess' file
                $fp = fopen($directory . "/.htaccess", "w");
                fputs($fp, "Deny from all", 200);
                fclose($fp);

                $dp = opendir($directory);

                while($line = readdir($dp))
                {

                    if($line != "." && $line != ".." && $line != ".htaccess")
                    {

                        echo "<a href=\"restrict_folder_access.php?file=" . $directory . "/" . $line . "\">" . $line . "</a><br />";

                    }

                }

                break;

            case "2" :

                // Creates the '.htaccess' file
                $fp = fopen($directory . "/.htaccess", "w");
                fputs($fp, "deny from all", 200);
                fclose($fp);

                $dp = opendir($directory);

                while($line = readdir($dp))
                {

                    if($line != "." && $line != ".." && $line != ".htaccess")
                    {

                        echo "<a href=\"restrict_folder_access.php?file=" . $directory . "/" . $line . "\">" . $line . "</a><br />";

                    }

                }

                break;

            default :

                // Deletes the '.htaccesss' file
                if(file_exists($directory . "/.htaccess"))
                {

                    unlink($directory . "/.htaccess");

                }

                $dp = opendir($directory);

                while($line = readdir($dp))
                {

                    if($line != "." && $line != "..")
                    {

                        echo "<a href=\"" . $directory . "/" . $line . "\" target=\"_blank\">" . $line . "</a><br />";

                    }

                }

                break;

        }

        ?>
    </div>
</div>
<?php include "./layouts/footer.php";?>
