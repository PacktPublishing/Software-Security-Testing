<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");

function sqli($data)
{

    switch($_COOKIE["security_level"])
    {

        case "0" :

            $data = no_check($data);
            break;

        case "1" :

            // Not working with PDO
            // $data = sqlite_escape_string($data);
            // Use a prepared statement instead!
            $data = sqli_check_4($data);
            break;

        case "2" :

            // Not working with PDO
            // $data = sqlite_escape_string($data);
            // Use a prepared statement instead!
            $data = sqli_check_4($data);
            break;

        default :

            $data = no_check($data);
            break;

    }

    return $data;

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>SQL Injection - Blind (SQLite)</h1>
        <br>
        <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="GET">

            <p>

                <label for="title">Search for a movie:</label>
                <input class="form-control" type="text" id="title" name="title" size="25">
                <br>
                <button class="btn btn-info" type="submit" name="action" value="search">Search</button>

            </p>

        </form>
        <?php

        if(isset($_REQUEST["title"]))
        {

            $title = $_REQUEST["title"];

            $user = "root";
            $pass = "";
            $db = new PDO('mysql:host=localhost;dbname=test', $user, $pass);

            $sql = "SELECT * FROM movies WHERE title = '" . sqli($title) . "' COLLATE NOCASE";

            $recordset = $db->query($sql);

            if(!$recordset)
            {

                die("<font color=\"red\">Incorrect syntax detected!</font>");

            }

            if($recordset->fetchColumn() > 0)
            {

                echo "The movie exists in our database!";

            }

            else
            {

                echo "The movie does not exist in our database!";

            }

            $db = null;

        }

        ?>
    </div>
</div>

<?php include "./layouts/footer.php";?>