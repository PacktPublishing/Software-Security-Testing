<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$language = "";

if(isset($_GET["language"]))
{

    switch($_COOKIE["security_level"])
    {

        case "0" :

            $language = $_GET["language"];

            break;

        case "1" :

            $language = $_GET["language"] . ".php";

            break;

        case "2" :

            $available_languages = array("lang_en.php", "lang_fr.php", "lang_nl.php");
            
            $language = $_GET["language"] . ".php";

            // $language = rlfi_check_1($language);

            break;

        default :

            $language = $_GET["language"];         

            break;

    }

}

?>


<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Remote & Local File Inclusion (RFI/LFI)</h1>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="GET">

            Select a language:

            <select class="form-control" name="language">

                <?php

                if($_COOKIE["security_level"] == "1" || $_COOKIE["security_level"] == "2")
                {

                    ?>
                    <option value="lang_en">English</option>
                    <option value="lang_fr">Français</option>
                    <option value="lang_nl">Nederlands</option>

                    <?php

                }

                else
                {

                    ?>
                    <option value="lang_en.php">English</option>
                    <option value="lang_fr.php">Français</option>
                    <option value="lang_nl.php">Nederlands</option>

                    <?php

                }

                ?>
            </select>
            <br>
            <button class="btn btn-info" type="submit" name="action" value="go">Go</button>

        </form>

        <br />
        <?php

        if(isset($_GET["language"]))
        {

            if($_COOKIE["security_level"] == "2")
            {

                if(in_array($language, $available_languages)) include($language);

            }

            else
            {
		include($language);

            }

        }

        ?>
    </div>
</div>
<?php include "./layouts/footer.php";?>
