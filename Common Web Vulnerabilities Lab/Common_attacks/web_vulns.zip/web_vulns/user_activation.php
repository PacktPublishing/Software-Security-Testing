<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("connect_i.php");

$message = "";

if(isset($_GET["user"]) && isset($_GET["activation_code"]) )
{
    
    $login = $_GET["user"];
    $login = mysqli_real_escape_string($link, $login);    
    
    $activation_code = $_GET["activation_code"];
    $activation_code = mysqli_real_escape_string($link, $activation_code);               
                
    $sql = "SELECT * FROM users WHERE login = '" . $login . "' AND BINARY activation_code = '" . $activation_code . "'";
                
    // Debugging
    // echo $sql;    

    $recordset = $link->query($sql);             
                             
    if(!$recordset)
    {

        die("Error: " . $link->error);

    }
                
    // Debugging                 
    // echo "<br />Affected rows: ";                
    // printf($link->affected_rows);
                
    $row = $recordset->fetch_object();   
                                                                           
    if($row)
    {

        // Debugging              
        // echo "<br />Row: "; 
        // print_r($row); 
                    
        $sql = "UPDATE users SET activation_code = NULL, activated = 1 WHERE login = '" . $login . "'";

        // Debugging
        // echo $sql;      

        $recordset = $link->query($sql);

        if(!$recordset)
        {

            die("Error: " . $link->error);

        }
                    
        // Debugging                  
        // echo "<br />Affected rows: ";                
        // printf($link->affected_rows);

        $message = "<font color=\"green\">User activated!</font>";

    }
                
    else
    {

        $message = "<font color=\"red\">User not or already activated!</font>";

    }

}

else

{
    
    $message = "<font color=\"red\">Not a valid input!</font>";

}

?>
<?php include './layouts/header.php'?>

    <h1>User Activation</h1>

    <p><?php

    echo $message;

    $link->close();

    ?></p>
<?php include './layouts/footer.php'?>
