<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("connect_i.php");

$message = "";

if(isset($_POST["action"]))
{

    $email = $_POST["email"];
    $email = mysqli_real_escape_string($link, $email);

    $reset_code = $_POST["reset_code"];
    $reset_code = mysqli_real_escape_string($link, $reset_code);

    $sql = "SELECT * FROM users WHERE email = '" . $email . "' AND BINARY reset_code = '" . $reset_code . "'";

    // Debugging
    // echo $sql;

    $recordset = $link->query($sql);

    if(!$recordset)
    {

        die("Error: " . $link->error);

    }

    // Debugging
    // echo "<br />Affected rows: ";
    // printf($link->affected_rows);

    $row = $recordset->fetch_object();

    if($row)
    {

        // Debugging
        // echo "<br />Row: ";
        // print_r($row);

        $secret = $_POST["secret"];
        $secret = mysqli_real_escape_string($link, $secret);
        $secret = htmlspecialchars($secret, ENT_QUOTES, "UTF-8");

        $sql = "UPDATE users SET reset_code = NULL, secret = '" . $secret . "' WHERE email = '" . $email . "'";

        // Debugging
        // echo $sql;

        $recordset = $link->query($sql);

        if(!$recordset)
        {

            die("Error: " . $link->error);

        }

        // Debugging
        // echo "<br />Affected rows: ";
        // printf($link->affected_rows);

        $message = "<font color=\"green\">Your secret has been changed!</font>";

    }

    else
    {

        $message = "<font color=\"red\">Your secret has not been changed!</font>";

    }

}

?>
<?php include './layouts/header.php'?>
    <div class="row">
        <div class="col-6">
            <h1>Change Secret</h1>

            <p>Please change your secret.</p>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

                <p><label for="secret">New secret:</label><br />
                    <input class="form-control" type="text" id="secret" name="secret"></p>

                <input type="hidden" id="email" name="email" value="<?php if(isset($_GET["email"])){echo htmlspecialchars($_GET["email"],ENT_QUOTES,'UTF-8');} ?>" />

                <input type="hidden" id="reset_code" name="reset_code" value="<?php if(isset($_GET["reset_code"])){echo htmlspecialchars($_GET["reset_code"],ENT_QUOTES,'UTF-8');} ?>" />

                <button class="btn btn-info" type="submit" name="action" value="change">Change</button>

            </form>

            <br />
            <?php

            echo $message;

            $link->close();

            ?>
        </div>
    </div>



<?php include './layouts/footer.php'?>