<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

?>

<?php include "./layouts/header.php";?>
<br>
<br>x
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Server Side Request Forgery (SSRF)</h1>

        <p>Server Side Request Forgery, or SSRF, is all about bypassing access controls such as firewalls.</p>

        <p>Use this web server as a proxy to:</p>

        <ul>

            <p>1. <a href="../evil/ssrf-1.txt" target="_blank">Port scan</a> hosts on the internal network using RFI.</p>

            <p>2. <a href="../evil/ssrf-2.txt" target="_blank">Access</a> resources on the internal network using XXE.</p>

            <p>3. <a href="../evil/ssrf-3.txt" target="_blank">Crash</a> my Samsung SmartTV (CVE-2013-4890) using XXE :)</p>

        </ul>
    </div>
</div>
<?php include "./layouts/footer.php";?>

    
