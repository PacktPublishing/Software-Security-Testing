<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

if(isset($_REQUEST["url"]) && ($_COOKIE["security_level"] == "1" || $_COOKIE["security_level"] == "2"))
{

    // Destroys the session and the cookie 'admin'
    if($_COOKIE["security_level"] == "2")
    {

        // Destroys the session 
        $_SESSION = array();
        session_destroy();

        // Deletes the cookies
        setcookie("admin", "", time()-3600, "/", "", false, false);
        setcookie("movie_genre", "", time()-3600, "/", "", false, false);
        setcookie("secret", "", time()-3600, "/", "", false, false);
        setcookie("top_security", "", time()-3600, "/", "", false, false);
        setcookie("top_security_nossl", "", time()-3600, "/", "", false, false);
        setcookie("top_security_ssl", "", time()-3600, "/", "", false, false);

    }

    switch($_REQUEST["url"])
    {
        case "1" :

            header("Location: http://itsecgames.blogspot.com");
            break;

        case "2" :

            header("Location: http://www.linkedin.com/in/malikmesellem");
            break;

        case "3" :

            header("Location: http://twitter.com/MME_IT");
            break;

        case "4" :

            header("Location: http://www.mmeit.be/en");
            break;

        default :

            header("Location: login.php");
            break;

    }

}

if(isset($_REQUEST["url"]) && ($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2"))
{
   
    // Debugging
    // echo $_REQUEST["url"];
    
    header("Location: " . $_REQUEST["url"]);

    exit;

}

?>




<?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>Unvalidated Redirects & Forwards (1)</h1>

            <p>Beam me up <?php if(isset($_SESSION["login"])){echo ucwords($_SESSION["login"]);} ?>...</p>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="GET">

                <?php

                if($_COOKIE["security_level"] == "1" || $_COOKIE["security_level"] == "2")
                {

                    ?>
                    <select class="form-control" name="url">

                        <option value="1">Blog</option>
                        <option value="2">LinkedIn</option>
                        <option value="3">Twitter</option>
                        <option value="4">Company website</option>

                    </select>
                    <?php

                }

                else
                {

                    ?>
                    <select class="form-control" name="url">

                        <option value="http://itsecgames.blogspot.com">Blog</option>
                        <option value="http://www.linkedin.com/in/malikmesellem">LinkedIn</option>
                        <option value="http://twitter.com/MME_IT">Twitter</option>
                        <option value="http://www.mmeit.be/en">Company website</option>

                    </select>
                    <?php

                }

                ?>
                <br>
                <button class="btn btn-info" type="submit" name="form" value="submit">Beam</button>

            </form>
        </div>
    </div>
<?php include "./layouts/footer.php";?>