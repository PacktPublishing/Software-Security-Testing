<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("connect.php");
include("selections.php");

$message = "";

if(isset($_GET["name"]) and $_GET["name"] != "")
{

    $name = $_GET["name"];

    $message = "<p>Hello " . ucwords(xss_check_3($name)) . ", please vote for your favorite movie.</p>";
    $message.= "<p>Remember, Tony Stark wants to win every time...</p>";

}

else
{

    header("Location: hpp-1.php");

    exit;

}

function hpp($data)
{
         
    switch($_COOKIE["security_level"])
    {
        
        case "0" : 
            
            $data = no_check($data);            
            break;
        
        case "1" :
            
            $data = urlencode($data);
            break;
        
        case "2" :            
                       
            $data = urlencode($data);
            break;
        
        default : 
            
            $data = no_check($data);            
            break;   

    }       

    return $data;

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>HTTP Parameter Pollution</h1>

        <?php echo $message ?>
        <table class="table">

            <tr >

                <td width="200"><b>Title</b></td>
                <td width="80"><b>Release</b></td>
                <td width="140"><b>Character</b></td>
                <td width="80"><b>Genre</b></td>
                <td width="80"><b>Vote</b></td>

            </tr>
            <?php
            $mysqli = new mysqli("localhost", "root", "", "bwapp");
            $sql = "SELECT * FROM movies";

            $recordset = mysqli_query($mysqli,$sql);

            if(!$recordset)
            {

                // die("Error: " . mysql_error());

                ?>

                <tr height="50">

                    <td colspan="5" width="580"><?php die("Error: " ); ?></td>
                    <!--
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    -->

                </tr>
                <?php

            }

            if(mysqli_num_rows($recordset) != 0)
            {

                while($row = mysqli_fetch_array($recordset))
                {

                    // print_r($row);

                    ?>

                    <tr height="30">

                        <td><?php echo $row["title"]; ?></td>
                        <td align="center"><?php echo $row["release_year"]; ?></td>
                        <td><?php echo $row["main_character"]; ?></td>
                        <td align="center"><?php echo $row["genre"]; ?></td>
                        <td align="center"> <a href=hpp-3.php?movie=<?php echo $row["id"]; ?>&name=<?php echo hpp($name);?>&action=vote>Vote</a></td>

                    </tr>
                    <?php

                }

            }

            mysqli_close($link);

            ?>

        </table>


    </div>
</div>
<?php include "./layouts/footer.php";?>

