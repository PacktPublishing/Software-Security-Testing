<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

David Bloom
Twitter: @philophobia78

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include "admin/settings.php";
function sqli($data)
{

    switch($_COOKIE["security_level"])
    {

        case "0" :

            $data = no_check($data);
            break;

        case "1" :

            // Not working with PDO
            // $data = sqlite_escape_string($data);
            // Use a prepared statement instead!
            $data = sqli_check_4($data);
            break;

        case "2" :

            // Not working with PDO
            // $data = sqlite_escape_string($data);
            // Use a prepared statement instead!
            $data = sqli_check_4($data);
            break;

        default :

            $data = no_check($data);
            break;

    }

    return $data;

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>SQL Injection (SQLite)</h1>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="GET">

                <p>

                    <label for="title">Search for a movie:</label>
                    <input  class="form-control" type="text" id="title" name="title" size="25">
                    <br>
                    <button class="btn btn-info" type="submit" name="action" value="search">Search</button> &nbsp;&nbsp;(requires the PHP SQLite module)

                </p>

            </form>

            <table class="table">

                <tr height="30" " align="center">

                    <td width="200"><b>Title</b></td>
                    <td width="80"><b>Release</b></td>
                    <td width="140"><b>Character</b></td>
                    <td width="80"><b>Genre</b></td>
                    <td width="80"><b>IMDb</b></td>

                </tr>
                <?php

                if(isset($_GET["title"]))
                {

                    $title = $_GET["title"];

                    $db = new PDO("sqlite:". $mysqli);

                    $sql = "SELECT * FROM movies WHERE title LIKE '%" . sqli($title) . "%'";

                    $recordset = $db->query($sql);

                    if(!$recordset)
                    {

                        ?>

                        <tr height="50">

                            <td colspan="5" width="580"><?php die("Error: " . $db->errorCode()); ?></td>

                        </tr>
                        <?php

                    }

                    $count = 0;

                    foreach($recordset as $row)
                    {

                        $count++;

                        ?>

                        <tr height="30">

                            <td><?php echo $row["title"]; ?></td>
                            <td align="center"><?php echo $row["release_year"]; ?></td>
                            <td><?php echo $row["main_character"]; ?></td>
                            <td align="center"><?php echo $row["genre"]; ?></td>
                            <td align="center"><a href="http://www.imdb.com/title/<?php echo $row["imdb"]; ?>" target="_blank">Link</a></td>

                        </tr>
                        <?php

                    }

                    if ($count == 0)
                    {

                        ?>

                        <tr height="30">

                            <td colspan="5" width="580">No movies were found!</td>

                        </tr>
                        <?php

                    }

                    $db = null;

                }

                else
                {

                    ?>

                    <tr height="30">

                        <td colspan="5" width="580"></td>

                    </tr>
                    <?php

                }

                ?>

            </table>

        </div>
    </div>

<?php include "./layouts/footer.php";?>