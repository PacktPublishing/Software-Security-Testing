<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

/* 
URL: http://php.net/manual/en/function.setcookie.php 

Writes a cookie
bool setcookie ( string $name [, string $value [, int $expire = 0 [, string $path [, string $domain [, bool $secure = false [, bool $httponly = false ]]]]]] )

Deletes a cookie
setcookie ("top_security", "", time()-3600);

Prints an individual cookie
echo $_COOKIE["top_security"];

Another way to debug/test is to view all cookies
print_r($_COOKIE); 
*/

$message = "";

// Deletes the cookie
setcookie("top_security", "", time()-3600, "/", "", false, false);

switch($_COOKIE["security_level"])
{
        
    case "0" :
        
        $message = "<p>Click <a href=\"top_security.php\" target=\_blank\>here</a> to access our top security page.</p>";
        
        // Deletes the cookies
        setcookie("top_security_nossl", "", time()-3600, "/", "", false, false);
        setcookie("top_security_ssl", "", time()-3600, "/", "", false, false);
        
        break;
        
    case "1" :
        
        $message = "<p>Click <a href=\"top_security.php\" target=\_blank\>here</a> to access our top security page.</p>";
        
        // Deletes the cookie
        setcookie("top_security_ssl", "", time()-3600, "/", "", false, false);
        
        if(!isset($_POST["form"]))
        {

            // Generates a non-SSL secured cookie
            // Generates a random token
            $token = uniqid(mt_rand(0,100000));
            $token = hash("sha256", $token);
            
            $_SESSION["top_security_nossl"] = $token;

            // The cookie will be available within the entire domain
            // Sets the Http Only flag        
            setcookie("top_security_nossl", $token, time()+3600, "/", "", false, true);

        }
        
        break;
        
    case "2" :
        
        $message = "<p>This page must be accessed over a SSL channel to fully function!<br />";
        $message.= "Click <a href=\"top_security.php\" target=\_blank\>here</a> to access our top security page.</p>";
        
        // Deletes the cookie
        setcookie("top_security_nossl", "", time()-3600, "/", "", false, false);

        if(!isset($_POST["form"]))
        {
            
            // Generates a non-SSL secured cookie
            // Generates a random token
            // $token = uniqid(mt_rand(0,100000));
            // $token = hash("sha256", $token);
            
            // $_SESSION["top_security_nossl"] = $token;

            // The cookie will be available within the entire domain
            // Sets the Http Only flag        
            // setcookie("top_security_nossl", $token, time()+3600, "/", "", false, true);          
            
            // Generates a SSL secured cookie
            // Generates a random token
            $token = uniqid(mt_rand(0,100000));
            $token = hash("sha256", $token);
            
            $_SESSION["top_security_ssl"] = $token;

            // The cookie will be available within the entire domain
            // Sets the Http Only flag and the Secure flag        
            setcookie("top_security_ssl", $token, time()+3600, "/", "", true, true);

        }
        
        break;
        
    default :
        
        $message = "<p>Click <a href=\"top_security.php\" target=\_blank\>here</a> to access our top security page.</p>";
        
        // Deletes the cookies
        setcookie("top_security_nossl", "", time()-3600, "/", "", false, false);
        setcookie("top_security_ssl", "", time()-3600, "/", "", false, false);
        
        break;
  
}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">

        <h1>Session Mgmt. - Strong Sessions</h1>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="POST">

            <p>

                Click the button to see your current cookies:
                <button class="btn btn-info" type="submit" name="form" value="cookies">Cookies</button>

            </p>

        </form>

        <?php echo $message;?>


        <table class="table">

            <tr">

                <td width="150"><b>Name</b></td>
                <td width="550"><b>Value</b></td>

            </tr>
            <?php

            if(isset($_POST["form"]))
            {

                foreach ($_COOKIE as $key => $cookie)
                {

                    ?>

                    <tr height="30">

                        <td><?php echo $key;?></td>
                        <td><?php echo $cookie;?></td>

                    </tr>
                    <?php

                }

            }

            ?>
        </table>
    </div>
</div>
<?php include "./layouts/footer.php";?>

