<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

$file = "../crossdomain.xml";

$handle = fopen($file, "w") or die("Cannot open file: " . $file);

if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
{

    $data = "<?xml version=\"1.0\"?>\n";
    $data.= "<!DOCTYPE cross-domain-policy SYSTEM \"http://www.macromedia.com/xml/dtds/cross-domain-policy.dtd\">\n";
    $data.= "<cross-domain-policy>\n";
    $data.= "  <allow-access-from domain=\"itsecgames.com\" />\n";
    $data.= "</cross-domain-policy>";

}

else
{

    $data = "<?xml version=\"1.0\"?>\n";
    $data.= "<!DOCTYPE cross-domain-policy SYSTEM \"http://www.macromedia.com/xml/dtds/cross-domain-policy.dtd\">\n";
    $data.= "<cross-domain-policy>\n";
    $data.= "  <allow-access-from domain=\"*\" />\n";
    $data.= "</cross-domain-policy>";

}

fwrite($handle, $data);

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Cross-Domain Policy File (Flash)</h1>

        <p>Using an insecure cross-domain policy file could expose this site to various attacks.</p>

        <p>Check the cross-domain policy file, and try to the steal the <a href="secret.php" target="_blank">secret</a>...</p>

        <p>HINT: <a href="../evil/xdx.php" target="_blank">Flash</a> and Silverlight applications are the source of all evil!</p>
    </div>
</div>
<?php include "./layouts/footer.php";?>



