<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

session_start();

$message = "";
$strong = false;

$secret = "PGk+PHA+U2VjdXJlIHRoZSB3b3JsZC4gRmlnaHQgY3JpbWUgYW5kIHNlbnNlbGVzcyB2aW9sZW5j";
$secret.= "ZS48YnIgLz5Eb24ndCBsZXQgVEhFTSB0YWtlIHlvdXIgbWluZCBhbmQgc291bC48YnIgLz5Mb3Zl";
$secret.= "IGVhY2ggb3RoZXIuPGJyIC8+WW91IGhhdmUgYSBtaXNzaW9uISBTcHJlYWQgdGhlc2Ugd29yZHMu";
$secret.= "Li48L3A+PHA+T2ggeWVhaC4uLiBJIHJlYWxseSBsb3ZlIHRob3NlIGhlcm8gbW92aWVzIDopPC9w";
$secret.= "PjxwPlJlZ2FyZHM8L3A+PHA+TWFsaWs8L3A+PC9pPg==";

/* Debugging
echo $_SESSION["top_security_nossl"];
echo "<br />";
echo $_COOKIE["top_security_nossl"];
*/

if(isset($_SESSION["login"]) && $_SESSION["login"])
{ 
   
    if(isset($_SESSION["top_security_nossl"]) && isset($_COOKIE["top_security_nossl"]) && $_SESSION["top_security_nossl"] == $_COOKIE["top_security_nossl"])
    {
        
        $message = "<p>Welcome " . ucwords($_SESSION["login"]) . ",</p><p>You have a valid session and a strong session!</p>";
        $message.= "<p>However, the <i>top security</i> cookie is not protected over a non-SSL channel!<br>";
        $message.= "You should try security level <i>high</i> in combination with a SSL channel...</p>";  
        
        $strong = true;  
        
    }    
    
    if(isset($_SESSION["top_security_ssl"]) && isset($_COOKIE["top_security_ssl"]) && $_SESSION["top_security_ssl"] == $_COOKIE["top_security_ssl"])
    {
        
        $message = "<p>Welcome " . ucwords($_SESSION["login"]) . ",</p><p>You have a valid session and a strong session.";                
        $message.= "<br />The <i>top security</i> cookie is protected over a non-SSL channel. This is maximum security!</p>";
        $message.= base64_decode($secret);
        
        $strong = true;
        
    }
        
    if($strong != true)
    {
        
        $message = "<p>Welcome " . ucwords($_SESSION["login"]) . ",</p><p>You have a valid session but not a strong session!</p>";
            
    }
    
}

else
{
    
    $message = "<p>You are not welcome here.</p><p>You don't have a valid session!</p>";    
    
}

?>
<?php include './layouts/header.php'?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>Session Mgmt. - Strong Sessions</h1>

            <?php echo $message;?>
        </div>
    </div>


<?php include "./layouts/footer.php";?>

</body>
    
</html>