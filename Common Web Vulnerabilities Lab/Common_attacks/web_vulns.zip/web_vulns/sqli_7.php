<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include("connect_i.php");

$entry = "";
$owner = "";
$message = "";

function sqli($data)
{

    include("connect_i.php");

    switch ($_COOKIE["security_level"]) {

        case "0" :

            $data = no_check($data);
            break;

        case "1" :

            $data = sqli_check_1($data);
            break;

        case "2" :

            $data = sqli_check_3($link, $data);
            break;

        default :

            $data = no_check($data);
            break;

    }

    return $data;

}

?>
<?php include './layouts/header.php' ?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>SQL Injection - Stored (Blog)</h1>
            <br>
            <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="POST">

                <label for="entry">Add an entry to our blog:</label>
                    <textarea class="form-control" name="entry" id="entry" cols="80" rows="3"></textarea>
                <br>
                <button class="btn btn-info" type="submit" name="blog" value="add">Add Entry</button>

                <?php

                if (isset($_POST["blog"])) {

                    $entry = sqli($_POST["entry"]);
                    $owner = $_SESSION["login"];

                    if ($entry == "") {

                        $message = "<font color=\"red\">Please enter some text...</font>";

                    } else {

                        $sql = "INSERT INTO blog (date, entry, owner) VALUES (now(),'" . $entry . "','" . $owner . "')";

                        $recordset = $link->query($sql);

                        if (!$recordset) {

                            die("Error: " . $link->error . "<br /><br />");

                        }

                        // Debugging
                        // echo $sql;

                        $message = "<font color=\"green\">The entry was added to our blog!</font>";

                    }

                }

                echo "&nbsp;&nbsp;" . $message;

                ?>

            </form>

            <br/>

            <table class="table">

                <tr >

                    <td width="20">#</td>
                    <td width="100"><b>Owner</b></td>
                    <td width="100"><b>Date</b></td>
                    <td width="445"><b>Entry</b></td>

                </tr>

                <?php

                // Selects all the records
                $sql = "SELECT * FROM blog";

                $recordset = $link->query($sql);

                if (!$recordset) {

                    // die("Error: " . $link->connect_error . "<br /><br />");

                    ?>
                    <tr height="50">

                        <td colspan="4" width="665"><?php die("Error: " . $link->error); ?></td>
                        <!--
                        <td></td>
                        <td></td>
                        <td></td>
                        -->

                    </tr>

                    <?php

                }

                while ($row = $recordset->fetch_object()) {

                    if ($_COOKIE["security_level"] == "2") {

                        ?>
                        <tr height="40">

                            <td align="center"><?php echo $row->id; ?></td>
                            <td><?php echo $row->owner; ?></td>
                            <td><?php echo $row->date; ?></td>
                            <td><?php echo xss_check_3($row->entry); ?></td>

                        </tr>

                        <?php

                    } else

                        if ($_COOKIE["security_level"] == "1") {

                            ?>
                            <tr height="40">

                                <td align="center"><?php echo $row->id; ?></td>
                                <td><?php echo $row->owner; ?></td>
                                <td><?php echo $row->date; ?></td>
                                <td><?php echo xss_check_4($row->entry); ?></td>

                            </tr>

                            <?php

                        } else {

                            ?>
                            <tr height="40">

                                <td align="center"><?php echo $row->id; ?></td>
                                <td><?php echo $row->owner; ?></td>
                                <td><?php echo $row->date; ?></td>
                                <td><?php echo $row->entry; ?></td>

                            </tr>

                            <?php

                        }

                }

                $recordset->close();

                $link->close();

                ?>
            </table>
        </div>
    </div>


<?php include './layouts/footer.php' ?>