<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include("connect_i.php");
include("admin/settings.php");

$message = "";

if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
{

    $message = "We currently have no cure for this bug. Try to configure SMTPS or IPSEC.";

}

if(isset($_POST["action"]))
{

    $login = $_SESSION["login"];

    // Debugging
    // echo $login;

    $sql = "SELECT * FROM users WHERE login = '" . $login . "'";

    // Debugging
    // echo $sql;

    $recordset = $link->query($sql);

    if(!$recordset)
    {

        die("Error: " . $link->error);

    }

    // Debugging
    // echo "<br />Affected rows: ";
    // printf($link->affected_rows);

    $row = $recordset->fetch_object();

    // If the user is present
    if($row)
    {

        if($smtp_server != "")
        {

            ini_set( "SMTP", $smtp_server);

        //Debugging
        // $debug = "true";

        }

        $secret = $row->secret;
        $email = $row->email;

        // Sends a mail to the user
        $subject = "bWAPP - Your Secret";

        $sender = $smtp_sender;

        $content = "Hello " . ucwords($login) . ",\n\n";
        $content.= "Your secret: " . $secret . "\n\n";
        $content.= "Greets from bWAPP!";

        $status = @mail($email, $subject, $content, "From: $sender");

        if($status != true)
        {

            $message = "<font color=\"red\">An e-mail could not be sent...</font>";

            // Debugging
            // die("Error: mail was NOT send");
            // echo "Mail was NOT send";

        }

        else
        {

            $message = "<font color=\"green\">An e-mail with your secret has been sent to " . $email . ".</font>";

        }

    }

}

?>

<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Man-in-the-Middle Attack (SMTP)</h1>
        <br>
        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

            Apparently you forgot your <button class="btn btn-info" type="submit" name="action" value="mail">secret</button>

        </form>

        <br />
        <?php

        echo $message;

        $link->close();

        ?>
    </div>
</div>
<?php include "./layouts/footer.php";?>


