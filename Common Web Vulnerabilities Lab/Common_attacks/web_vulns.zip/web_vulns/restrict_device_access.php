<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$message = "";
$authorized_device = false;

// No differences between the security levels
switch ($_COOKIE["security_level"]) {

    case "0" :

        $authorized_device = check_user_agent();
        break;

    case "1" :

        $authorized_device = check_user_agent();
        break;

    case "2" :

        $authorized_device = check_user_agent();
        break;

    default :

        $authorized_device = check_user_agent();
        break;

}

function check_user_agent()
{

    $user_agent = $_SERVER["HTTP_USER_AGENT"];

    // Debugging
    // echo $user_agent;

    $authorized_device = false;

    $devices = array("iPhone", "iPad", "iPod", "Android");

    // Searches for a string in an array
    foreach ($devices as $str) {

        // echo $str;
        if (strpos($user_agent, $str) !== false) {

            // Debugging    
            // echo $user_agent . " contains the word " . $str;

            $authorized_device = true;

        }

    }

    return $authorized_device;

}

?>



<?php include "./layouts/header.php"; ?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Restrict Device Access</h1>

        <p>Only some authorized devices have access to the content of this page.</p>

        <p>

            <?php

            if ($authorized_device != false) {

                $message = "<font color=\"green\">This is a smartphone or a tablet computer!</font>";

            } else {

                $message = "<font color=\"red\">This is not a smartphone or a tablet computer (Apple/Android)!</font>";

            }

            echo $message;

            ?>
    </div>
</div>
<?php include "./layouts/footer.php"; ?>


