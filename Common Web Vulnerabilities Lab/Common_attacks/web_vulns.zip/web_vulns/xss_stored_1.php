<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("connect_i.php");
include("selections.php");

$entry = "";
$owner = "";
$message = "";

function xss($data)
{
    
    include("connect_i.php");

    switch($_COOKIE["security_level"])
    {

        case "0" : 

            $data = sqli_check_3($link, $data);
            break;

        case "1" :

            $data = sqli_check_3($link, $data);
            // $data = xss_check_4($data);
            break;

        case "2" :

            $data = sqli_check_3($link, $data);
            // $data = xss_check_3($data);
            break;

        default :

            $data = sqli_check_3($link, $data);
            break;

    }

    return $data;

}

if(isset($_POST["entry_add"]))
{

    $entry = xss($_POST["entry"]);
    $owner = $_SESSION["login"];

    if($entry == "")
    {

        $message =  "<font color=\"red\">Please enter some text...</font>";

    }

    else            
    { 

        $sql = "INSERT INTO blog (date, entry, owner) VALUES (now(),'" . $entry . "','" . $owner . "')";

        $recordset = $link->query($sql);

        if(!$recordset)
        {

            die("Error: " . $link->error . "<br /><br />");

        }

        // Debugging
        // echo $sql;

        $message = "<font color=\"green\">Your entry was added to our blog!</font>";

    }

}

else
{

    if(isset($_POST["entry_delete"]))
    {

        $sql = "DELETE from blog WHERE owner = '" . $_SESSION["login"] . "'";

        $recordset = $link->query($sql);

        if(!$recordset)
        {

            die("Error: " . $link->error . "<br /><br />");

        }

        // Debugging
        // echo $sql;

        $message = "<font color=\"green\">All your entries were deleted!</font>";

    }

}

?>

<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Stored (Blog)</h1>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

            <table>

                <tr>

                    <textarea class="form-control" name="entry" id="entry" cols="80" rows="3"></textarea>

                </tr>

                <tr>

                    <td width="79" align="left">

                        <button class="btn btn-info" type="submit" name="blog" value="submit">Submit</button>

                    </td>

                    <td width="85" align="center">

                        <label for="entry_add">Add:</label>
                        <input type="checkbox" id="entry_add" name="entry_add" value="" checked="on">

                    </td>

                    <td width="100" align="center">

                        <label for="entry_all">Show all:</label>
                        <input type="checkbox" id="entry_all" name="entry_all" value="">

                    </td>

                    <td width="106" align="center">

                        <label for="entry_delete">Delete:</label>
                        <input type="checkbox" id="entry_delete" name="entry_delete" value="">

                    </td>

                    <td width="7"></td>

                    <td align="left"><?php echo $message;?></td>

                </tr>

            </table>

        </form>

        <br />

        <table class="table">

            <tr>

                <td width="20">#</td>
                <td width="100"><b>Owner</b></td>
                <td width="100"><b>Date</b></td>
                <td width="445"><b>Entry</b></td>

            </tr>

            <?php

            // Selects all the records

            $entry_all = isset($_POST["entry_all"]) ? 1 : 0;

            if($entry_all == false)
            {

                $sql = "SELECT * FROM blog WHERE owner = '" . $_SESSION["login"] . "'";

            }

            else
            {

                $sql = "SELECT * FROM blog";

            }

            $recordset = $link->query($sql);

            if(!$recordset)
            {

                // die("Error: " . $link->connect_error . "<br /><br />");

                ?>
                <tr height="50">

                    <td colspan="4" width="665"><?php die("Error: " . $link->error);?></td>
                    <!--
                    <td></td>
                    <td></td>
                    <td></td>
                    -->

                </tr>

                <?php

            }

            while($row = $recordset->fetch_object())
            {

                if($_COOKIE["security_level"] == "2")
                {



                    ?>
                    <tr height="40">

                        <td align="center"><?php echo $row->id; ?></td>
                        <td><?php echo $row->owner; ?></td>
                        <td><?php echo $row->date; ?></td>
                        <td><?php echo xss_check_3($row->entry); ?></td>

                    </tr>

                    <?php

                }

                else

                    if($_COOKIE["security_level"] == "1")
                    {

                        ?>
                        <tr height="40">

                            <td align="center"><?php echo $row->id; ?></td>
                            <td><?php echo $row->owner; ?></td>
                            <td><?php echo $row->date; ?></td>
                            <td><?php echo xss_check_4($row->entry); ?></td>

                        </tr>

                        <?php

                    }

                    else

                    {

                        ?>
                        <tr height="40">

                            <td align="center"><?php echo $row->id; ?></td>
                            <td><?php echo $row->owner; ?></td>
                            <td><?php echo $row->date; ?></td>
                            <td><?php echo $row->entry; ?></td>

                        </tr>

                        <?php

                    }

            }

            $recordset->close();

            $link->close();

            ?>
        </table>

    </div>
</div>
<?php include "./layouts/footer.php";?>

