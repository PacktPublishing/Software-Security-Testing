<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include("connect_i.php");

$login = $_SESSION["login"];

$sql = "SELECT * FROM users WHERE login = '" . $login . "'";

$recordset = $link->query($sql);

if(!$recordset)
{

    die("Error: " . $link->error);

}

$row = $recordset->fetch_object();

if($row)
{

    $secret = $row->secret;

}

$link->close();

?>
<!DOCTYPE html>
<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!--<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Architects+Daughter">-->
<link rel="stylesheet" type="text/css" href="stylesheets/stylesheet.css" media="screen" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<!--<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
<script src="js/html5.js"></script>

<script>

if(typeof(Storage) !== "undefined")
{

    localStorage.login = "<?php echo $_SESSION["login"]?>";
    localStorage.secret = "<?php if($_COOKIE["security_level"] != "1" and $_COOKIE["security_level"] != "2"){echo $secret;} else{echo hash("sha1", $secret);}?>";

}
else
{

    alert("Sorry, your browser does not support web storage...");

}

</script>

<title>Cyber Academy</title>

</head>

<body>
<?php include "./layouts/header1.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>HTML5 Web Storage (Secret)</h1>

        <p>Your login name and secret have been stored as HTML5 web storage!</p>

        <p>HINT: try to grab it using XSS...</p>
    </div>
</div>







</body>

</html>