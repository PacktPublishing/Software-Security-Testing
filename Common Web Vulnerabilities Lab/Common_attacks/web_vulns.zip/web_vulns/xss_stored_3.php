<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("connect_i.php");
include("selections.php");
include("functions_external.php");

function xss($data)
{
         
    switch($_COOKIE["security_level"])
    {
        
        case "0" : 
            
            $data = no_check($data);            
            break;
        
        case "1" :
            
            $data = xss_check_4($data);
            break;
        
        case "2" :            
                       
            $data = xss_check_3($data);            
            break;
        
        default : 
            
            $data = no_check($data);            
            break;   

    }       

    return $data;

}

$message = "";

$login = $_SESSION["login"];

if(isset($_POST["action"]))
{

    if(isset($_REQUEST["secret"]))
    {

        $secret = $_REQUEST["secret"];

        if($secret == "")
        {

            $message = "<font color=\"red\">Please enter a new secret...</font>";       

        }

        else
        {
            
            // If the security level is not MEDIUM or HIGH
            if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2") 
            {

                if(isset($_REQUEST["login"]) && $_REQUEST["login"])
                {

                    $login = $_REQUEST["login"];
                    $login = mysqli_real_escape_string($link, $login);
                    
                    $secret = mysqli_real_escape_string($link, $secret);
                    $secret = xss($secret);

                    $sql = "UPDATE users SET secret = '" . $secret . "' WHERE login = '" . $login . "'";

                    // Debugging
                    // echo $sql;      

                    $recordset = $link->query($sql);

                    if(!$recordset)
                    {

                        die("Connect Error: " . $link->error);

                    }

                    $message = "<font color=\"green\">The secret has been changed!</font>";

                }

                else 
                {

                    $message = "<font color=\"red\">Invalid login!</font>"; 

                }
                
            }

            else
            {
                
                // If the security level is MEDIUM or HIGH
                if(!isset($_REQUEST["token"]) or !isset($_SESSION["token"]) or $_REQUEST["token"] != $_SESSION["token"])
                {

                    $message = "<font color=\"red\">Invalid token!</font>";            

                }

                else
                {

                    $secret = mysqli_real_escape_string($link, $secret);
                    $secret = htmlspecialchars($secret, ENT_QUOTES, "UTF-8");

                    $sql = "UPDATE users SET secret = '" . $secret . "' WHERE login = '" . $login . "'";

                    // Debugging
                    // echo $sql;      

                    $recordset = $link->query($sql);

                    if(!$recordset)
                    {

                        die("Connect Error: " . $link->error);

                    }

                    $message = "<font color=\"green\">The secret has been changed!</font>";

                }
                
            }

        }

    }
    
    else
    {
    
        $message = "<font color=\"red\">Invalid secret!</font>"; 
        
    }   
    
}

// A random token is generated when the security level is MEDIUM or HIGH
if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
{

    $token = sha1(uniqid(mt_rand(0,100000)));
    $_SESSION["token"] = $token;

}

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>XSS - Stored (Change Secret)</h1>

        <p>Change your secret.</p>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

            <label for="secret">New secret:</label>
                <input type="text" id="secret" class="form-control" name="secret">
            <?php

            if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2")
            {

                ?>

                <input type="hidden" name="login" value="<?php echo $login;?>">
                <?php

            }

            else
            {

                ?>

                <input type="hidden" id="token" name="token" value="<?php echo $_SESSION["token"]?>">
                <?php

            }

            ?>
            <br>
            <button class="btn btn-info" type="submit" name="action" value="change">Change</button>

        </form>

        </br >
        <?php

        echo $message;

        $link->close();

        ?>

    </div>
</div>
<?php include "./layouts/footer.php";?>
    

