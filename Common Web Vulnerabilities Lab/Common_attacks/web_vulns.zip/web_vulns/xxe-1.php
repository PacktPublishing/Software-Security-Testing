<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

?>


<?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>XML External Entity Attacks (XXE)</h1>

            <p>Reset your secret to <input class="btn btn-info" type="button" OnClick="ResetSecret();" value="Any bugs?"></p>

            <script type="text/javascript">

                function ResetSecret()
                {
                    var xmlHttp;
                    // Code for IE7+, Firefox, Chrome, Opera, Safari
                    if(window.XMLHttpRequest)
                    {
                        xmlHttp = new XMLHttpRequest();
                    }
                    // Code for IE6, IE5
                    else
                    {
                        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlHttp.open("POST","xxe-2.php",true);
                    xmlHttp.setRequestHeader("Content-type","text/xml; charset=UTF-8");
                    xmlHttp.send("<reset><login><?php if(isset($_SESSION["login"])){echo $_SESSION["login"];}?></login><secret>Any bugs?</secret></reset>");
                }

            </script>
        </div>
    </div>
<?php include "./layouts/footer.php";?>