<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include("connect.php");

if($_COOKIE["security_level"] == "2")
{
    
    header("Location: sqli_13-ps.php");
    
    exit;
    
}
$mysqli = new mysqli("localhost", "root", "", "bwapp");
// Selects all the records
$sql = "SELECT * FROM movies";

$recordset = mysqli_query($mysqli, $sql);

function sqli($data)
{
         
    switch($_COOKIE["security_level"])
    {
        
        case "0" : 
            
            $data = no_check($data);            
            break;
        

        default : 
            
            $data = no_check($data);            
            break;   

    }       

    return $data;

}

?>
<?php include './layouts/header.php'?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>SQL Injection (POST/Select)</h1>
        <br>
        <form action="<?php echo($_SERVER["SCRIPT_NAME"]); ?>" method="POST">

            Select a movie:

                <select class="form-control" name="movie">

                    <?php

                    // Fills the 'select' object
                    while($row = mysqli_fetch_array($recordset))
                    {

                        ?>
                        <option value="<?php echo $row["id"];?>"><?php echo $row["title"];?></option>
                        <?php

                    }

                    ?>

                </select>
                <br>
                <button class="btn btn-info" type="submit" name="action" value="go">Go</button>

            </p>

        </form>

        <table class="table">

            <tr>

                <td width="200"><b>Title</b></td>
                <td width="80"><b>Release</b></td>
                <td width="140"><b>Character</b></td>
                <td width="80"><b>Genre</b></td>
                <td width="80"><b>IMDb</b></td>

            </tr>
            <?php

            if(isset($_POST["movie"]))
            {

                $id = $_POST["movie"];

                $sql = "SELECT * FROM movies";

                // If the user selects a movie
                if($id)
                {

                    $sql.= " WHERE id = " . sqli($id);

                }

                $recordset = mysqli_query($mysqli, $sql);

                if(!$recordset)
                {

                    // die("Error: " . mysql_error());

                    ?>

                    <tr height="50">

                        <td colspan="5" width="580"><?php die("Error: " . mysql_error()); ?></td>
                        <!--
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        -->

                    </tr>
                    <?php

                }

                // Shows the movie details when a valid record exists
                if(mysqli_num_rows($recordset) != 0)
                {

                    $row = mysqli_fetch_array($recordset);

                    // print_r($row);

                    ?>

                    <tr height="30">

                        <td><?php echo $row["title"]; ?></td>
                        <td align="center"><?php echo $row["release_year"]; ?></td>
                        <td><?php echo $row["main_character"]; ?></td>
                        <td align="center"><?php echo $row["genre"]; ?></td>
                        <td align="center"><a href="http://www.imdb.com/title/<?php echo $row["imdb"]; ?>" target="_blank">Link</a></td>

                    </tr>
                    <?php

                }

                else
                {

                    ?>

                    <tr height="30">

                        <td colspan="5" width="580">No movies were found!</td>
                        <!--
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        -->

                    </tr>
                    <?php

                }

            }

            else
            {

                ?>

                <tr height="30">

                    <td colspan="5" width="580"></td>
                    <!--
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    -->

                </tr>
                <?php

            }

            mysqli_close($link);

            ?>

        </table>

    </div>
</div>

<?php include './layouts/footer.php'?>