<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("selections.php");
include("admin/settings.php");

if(isset($_POST["form"]) && isset($_POST["security_level"]))    
{
    
    $security_level_cookie = $_POST["security_level"];
    
    switch($security_level_cookie)
    {

        case "0" :

            $security_level_cookie = "0";
            break;

        case "1" :

            $security_level_cookie = "1";
            break;

        case "2" :

            $security_level_cookie = "2";
            break;

        default : 

            $security_level_cookie = "0";
            break;

    }

    if($evil_bee == 1)
    {

        setcookie("security_level", "666", time()+60*60*24*365, "/", "", false, false);

    }
    
    else        
    {
      
        setcookie("security_level", $security_level_cookie, time()+60*60*24*365, "/", "", false, false);
        
    }

    header("Location: " . $_SERVER["SCRIPT_NAME"]);
    
    exit;

}
        
?>


<?php include "./layouts/header.php"?>
        <br>
        <br>

    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>Set Security Level</h1>

            <p>Your security level is <b><?php echo $security_level ?></b>.</p>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

                <p><label for="security_level">Set the security level:</label><br />

                    <select class="form-control" name="security_level">

                        <option value="0">low</option>
                        <option value="1">medium</option>
                        <option value="2">high</option>

                    </select>

                    <button class="btn btn-info mt-3" type="submit" name="form" value="submit">Set</button>

                </p>

            </form>
        </div>
    </div>
        

<?php include "./layouts/footer.php";?>

