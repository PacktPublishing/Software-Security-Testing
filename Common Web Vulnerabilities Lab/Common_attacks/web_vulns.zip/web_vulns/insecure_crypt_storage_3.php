<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");
include("functions_external.php");
include("connect_i.php");

$login = $_SESSION["login"];

$sql = "SELECT * FROM users WHERE login = '" . $login . "'";

$recordset = $link->query($sql);

if(!$recordset)
{

    die("Error: " . $link->error);

}

$row = $recordset->fetch_object();

if($row)
{

    $secret = $row->secret;

    if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
    {

        $secret = sha1($secret);

    }

    else
    {

        $secret = base64_encode($secret);

    }

    setcookie("secret", $secret, time()+3600, "/", "", false, false);

}

$link->close();

?>

<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Base64 Encoding (Secret)</h1>

        <p>Your secret has been stored as an encrypted cookie!</p>

        <p>HINT: try to decrypt it...</p>
    </div>
</div>
<?php include "./layouts/footer.php";?>


