<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

David Bloom
Twitter: @philophobia78

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

?>
<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>SQL Injection (AJAX/JSON/jQuery)</h1>
        <br>
        <form>

            <p>

                <label for="title">Search for a movie:</label>
                <input class="form-control" type="text" id="title" name="title" size="25">

            </p>

        </form>
        <br>
        <table id="table" class="table">

            <tr >

                <td width="200"><b>Title</b></td>
                <td width="80"><b>Release</b></td>
                <td width="140"><b>Character</b></td>
                <td width="80"><b>Genre</b></td>
                <td width="80"><b>IMDb</b></td>

            </tr>

        </table>

        <script>

            $("#title").keyup(function(){
                // Searches for a movie title
                var search = {title: $("#title").val()};

                // AJAX call
                $.getJSON("sqli_10-2.php", search, function(data){
                    init_table();
                    // Constructs the table from the JSON data
                    var total = 0;
                    $.each(data, function(key, val){
                        total++;
                        $("#table tr:last").after("<tr><td>" + val.title + "</td><td align='center'>" + val.release_year + "</td><td>" + val.main_character + "</td><td align='center'>" + val.genre + "</td><td align='center'><a href='http://www.imdb.com/title/" + val.imdb + "' target='_blank'>Link</a></td></tr>");
                    });
                    // Empty result
                    if (total == 0)
                    {
                        $("#table tr:last").after("<tr height='30'><td colspan='5' width='580'>No movies were found!</td></tr>");
                    }
                })

            });

            function init_table(){
                $("#table").html("<tr>" +
                    "<td width='200'><b>Title</b></td>" +
                    "<td width='80'><b>Release</b></td>" +
                    "<td width='140'><b>Character</b></td>" +
                    "<td width='80'><b>Genre</b></td>" +
                    "<td width='80'><b>IMDb</b></td>" +
                    "</tr>"
                );
            }

        </script>

    </div>
</div>

<?php include "./layouts/footer.php";?>