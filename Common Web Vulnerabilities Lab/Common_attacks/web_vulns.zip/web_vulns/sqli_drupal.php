<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

?>
<?php include './layouts/header.php' ?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>Drupal SQL Injection (Drupageddon)</h1>
        <br>
            <p>The <a href="../drupal/" target="_blank">Drupal</a> version is vulnerable to SQL injection! (<a
                        href="http://sourceforge.net/projects/bwapp/files/bee-box/" target="_blank">bee-box</a> only)
            </p>
            <br>
            <p>HINT: <a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2014-3704" target="_blank">CVE-2014-3704</a>
            </p>
        </div>
    </div>


<?php include './layouts/footer.php' ?>