<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

/* 
URL: http://php.net/manual/en/function.setcookie.php 

Writes a cookie
bool setcookie ( string $name [, string $value [, int $expire = 0 [, string $path [, string $domain [, bool $secure = false [, bool $httponly = false ]]]]]] )

Deletes a cookie
setcookie ("top_security", "", time()-3600);

Prints an individual cookie
echo $_COOKIE["top_security"];

Another way to debug/test is to view all cookies
print_r($_COOKIE); 
*/

switch($_COOKIE["security_level"])
{
           
    case "0" : 
       
        // The cookie will be available within the entire domain
        setcookie("top_security", "no", time()+3600, "/", "", false, false);
        break;
        
    case "1" :
            
        // The cookie will be available within the entire domain
        // Sets the Http Only flag
        setcookie("top_security", "maybe", time()+3600, "/", "", false, true);        
        break;
        
    case "2" :            

        // The cookie will be available within the entire domain
        // The cookie expires at end of the session
        // Sets the Http Only flag
        setcookie("top_security", "yes", time()+300, "/", "", false, true); 
        break;
        
    default : 
            
        // The cookie will be available within the entire domain
        setcookie("top_security", "no", time()+3600, "/", "", false, false);       
        break;
       
}

?>
<!DOCTYPE html>
<html>
    
<head>
        
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!--<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Architects+Daughter">-->
<link rel="stylesheet" type="text/css" href="stylesheets/stylesheet.css" media="screen" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<!--<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
<script src="js/html5.js"></script>

<title>Cyber Academy</title>

<script>
    
function show_my_cookies()
{
    
    alert(document.cookie)
    
}

</script>

</head>

<body>

<div class="row">
    <br>
    <br>
    <div class="col-2"></div>
    <div class="col-8">

        <h1>Session Mgmt. - Cookies (HTTPOnly)</h1>
        <br>
        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

            <p>

                Click the button to see your current cookies:
                <button class="btn btn-info" type="submit" name="form" value="cookies">Cookies</button>

            </p>

        </form>

        <p>Click <a class="btn btn-info" href="javascript:show_my_cookies()">here</a> to see your cookies with JavaScript.</p>

        <table class="table">

            <tr >

                <td width="100"><b>Name</b></td>
                <td width="300"><b>Value</b></td>

            </tr>
            <?php

            if(isset($_POST["form"]))
            {

                foreach ($_COOKIE as $key => $cookie)
                {

                    ?>

                    <tr height="30">

                        <td><?php echo $key;?></td>
                        <td><?php echo $cookie;?></td>

                    </tr>
                    <?php

                }

            }

            ?>
    </div>
</div>

    </table>
<?php include "./layouts/footer.php";?>