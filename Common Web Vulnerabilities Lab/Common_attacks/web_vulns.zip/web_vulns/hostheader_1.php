<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

?>
<?php include "./layouts/header.php";?>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<!--<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Architects+Daughter">-->
<?php

if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2")
{

?>
<link rel="stylesheet" type="text/css" href="http://<?php echo $_SERVER["HTTP_HOST"]?>/stylesheets/stylesheet.css" media="screen" />
<?php

}

else
{
?>
<link rel="stylesheet" type="text/css" href="stylesheets/stylesheet.css" media="screen" />
<?php

}

?>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />

<!--<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
<?php

if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2")
{

?>
<script src="http://<?php echo $_SERVER["HTTP_HOST"]?>/js/html5.js"></script>
<?php

}

else
{
?>
<script src="js/html5.js"></script>
<?php

}

?>





<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <h1>Host Header Attack (Cache Poisoning)</h1>

        <?php

        if($_COOKIE["security_level"] != "1" && $_COOKIE["security_level"] != "2")
        {

            $session_id = session_id();

            ?>
            <p>Click <a href="http://<?php echo $_SERVER["HTTP_HOST"]?>/portal.php">here</a> to go back to the portal.</p>
            <?php

        }

        else
        {
            ?>
            <p>Click <a href="portal.php">here</a> to go back to the portal.</p>
            <?php

        }

        ?>
    </div>
</div>
<?php include "./layouts/footer.php";?>

