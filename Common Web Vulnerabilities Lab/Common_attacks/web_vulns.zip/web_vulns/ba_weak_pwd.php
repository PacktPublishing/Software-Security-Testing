<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$message = "";
$login = "test";
  
switch($_COOKIE["security_level"])
{

    case "0" : 

        $password = "test";
        break;

    case "1" :

        $password = "test123";
        break;

    case "2" :

        $password = "Test123";
        break;

    default :

        $password = "test";
        break;

}

?>

<?php include "./layouts/header.php";?>
<br>
<br>
<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <?php include "./layouts/footer.php";?>
        <h1>Broken Auth. - Weak Passwords</h1>
<br>
        <p>Enter your credentials.</p>

        <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

            <label for="login">Login:</label>
                <input class="form-control" type="text" id="login" name="login" size="20" autocomplete="off" />

            <label for="password">Password:</label>
                <input class="form-control" type="password" id="password" name="password" size="20" autocomplete="off" />
        <br>
            <button class="btn btn-info" type="submit" name="form" value="submit">Login</button>

        </form>

        <br />
        <?php

        if(isset($_POST["form"]))
        {

            if($_POST["login"] == $login && $_POST["password"] == $password)
            {

                $message = "<font color=\"green\">Successful login!</font>";

            }

            else
            {

                $message = "<font color=\"red\">Invalid credentials!</font>";

            }

        }

        echo $message;

        ?>

<?php include "./layouts/footer.php";?>