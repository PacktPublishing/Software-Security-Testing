<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

if($_COOKIE["security_level"] == "1" or $_COOKIE["security_level"] == "2")
{
        
    header("X-Frame-Options: DENY");
}

$ticket_price = 15;

?>


<?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">

            <h1>ClickJacking (Movie Tickets)</h1>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">

                <p>How many movie tickets would you like to order? (<?php echo $ticket_price ?> EUR per ticket)</p>

                <p>I would like to order <input type="text" name="ticket_quantity" value="10" size="2"> tickets.</p>

                <p>HINT: open the evil <a href="../evil/clickjacking.htm" target="_blank">ClickJacking page</a> in a new tab...</p>

                <br />

                <button class="btn btn-info" type="submit" name="action" value="order">Confirm</button>

            </form>

            <br />

            <?php

            if(isset($_REQUEST["ticket_quantity"]))
            {

                $ticket_quantity = abs($_REQUEST["ticket_quantity"]);
                $total_amount = $ticket_quantity * $ticket_price;

                echo "<p>You ordered <b>" . $ticket_quantity . "</b> movie tickets. Total amount charged from your account automatically: <b>" . $total_amount . " EUR</b>.</p>";
                echo "<p>Thank you for your order!</p>";

                $_SESSION["amount"] = $_SESSION["amount"] - $total_amount;

            }

            ?>
        </div>
    </div>
<?php include "./layouts/footer.php";?>