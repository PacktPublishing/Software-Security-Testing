<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("selections.php");

/* 
URL: http://php.net/manual/en/function.setcookie.php 

Writes a cookie
bool setcookie ( string $name [, string $value [, int $expire = 0 [, string $path [, string $domain [, bool $secure = false [, bool $httponly = false ]]]]]] )

Deletes a cookie
setcookie ("top_security", "", time()-3600);

Prints an individual cookie
echo $_COOKIE["top_security"];

Another way to debug/test is to view all cookies
print_r($_COOKIE); 
*/

$message = "";

// Deletes the cookies
setcookie("top_security_nossl", "", time()-3600, "/", "", false, false);
setcookie("top_security_ssl", "", time()-3600, "/", "", false, false);

switch($_COOKIE["security_level"])
{
        
    case "0" :
        
        $message.= "<p>Browse to another page to see if the cookies are protected over a non-SSL channel.</p>";
        
        // The cookie will be available within the entire domain
        // Sets the Http Only flag
        setcookie("top_security", "no", time()+3600, "/", "", false, true);        
        break;
        
    case "1" :
        
        $message = "<p>This page must be accessed over a SSL channel to fully function!<br />";
        $message.= "Browse to another page to see if the cookies are protected over a non-SSL channel.</p>";
            
        // The cookie will be available within the entire domain
        // Sets the Http Only flag and the Secure flag
        setcookie("top_security", "maybe", time()+3600, "/", "", true, true);        
        break;
        
    case "2" :
        
        $message = "<p>This page must be accessed over a SSL channel to fully function!<br />";
        $message.= "Browse to another page to see if the cookies are protected over a non-SSL channel.</p>";

        // The cookie will be available within the entire domain
        // The cookie expires at end of the session
        // Sets the Http Only flag and the Secure flag
        setcookie("top_security", "yes", time()+300, "/", "", true, true);        
        break;
        
    default :
        
        $message.= "<p>Browse to another page to see if the cookies are protected over a non-SSL channel</p>";
            
        // The cookie will be available within the entire domain
        // Sets the Http Only flag
        setcookie("top_security", "no", time()+3600, "/", "", false, true);        
        break;;
       
}

?>
<?php include "./layouts/header.php";?>
    <br>
    <br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>Session Mgmt. - Cookies (Secure)</h1>

            <form action="<?php echo($_SERVER["SCRIPT_NAME"]);?>" method="POST">



                Click the button to see your current cookies:

                <button class="btn btn-info" type="submit" name="form" value="cookies">Cookies</button>



            </form>

            <?php echo $message;?>

            <br>
            <table class="table">

                <tr >

                    <td width="100"><b>Name</b></td>
                    <td width="300"><b>Value</b></td>

                </tr>
                <?php

                if(isset($_POST["form"]))
                {

                    foreach($_COOKIE as $key => $cookie)
                    {

                        ?>

                        <tr height="30">

                            <td><?php echo $key;?></td>
                            <td><?php echo $cookie;?></td>

                        </tr>
                        <?php

                    }

                }

                ?>
            </table>

        </div>
    </div>

<br />    
   
<?php include "./layouts/footer.php";?>