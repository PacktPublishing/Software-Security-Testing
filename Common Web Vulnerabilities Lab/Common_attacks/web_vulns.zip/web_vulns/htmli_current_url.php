<?php

/*

bWAPP, or a buggy web application, is a free and open source deliberately insecure web application.
It helps security enthusiasts, developers and students to discover and to prevent web vulnerabilities.
bWAPP covers all major known web vulnerabilities, including all risks from the OWASP Top 10 project!
It is for security-testing and educational purposes only.

Enjoy!

Malik Mesellem
Twitter: @MME_IT

bWAPP is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (http://creativecommons.org/licenses/by-nc-nd/4.0/). Copyright © 2014 MME BVBA. All rights reserved.

*/

include("security.php");
include("security_level_check.php");
include("functions_external.php");
include("selections.php");

$url= "";

        
switch($_COOKIE["security_level"])
{

    case "0" :

        // $url = "http://" . $_SERVER["HTTP_HOST"] . urldecode($_SERVER["REQUEST_URI"]);
        $url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];               
        break;

    case "1" :

        $url = "<script>document.write(document.URL)</script>";
        break;

    case "2" :

        $url = "http://" . $_SERVER["HTTP_HOST"] . xss_check_3($_SERVER["REQUEST_URI"]);
        break;

    default :

        // $url = "http://" . $_SERVER["HTTP_HOST"] . urldecode($_SERVER["REQUEST_URI"]);
        $url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];               
        break;

}

?>

    <?php include "./layouts/header.php";?>
<br>
<br>
    <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
            <h1>HTML Injection - Reflected (URL)</h1>

            <?php echo "<p align=\"left\">Your current URL: <i>" . $url . "</i></p>";?>
        </div>

    </div>


<?php include "./layouts/footer.php";?>